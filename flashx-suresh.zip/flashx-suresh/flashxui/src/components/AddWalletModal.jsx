import React, { useState } from 'react';
import { X } from 'lucide-react';
import axios from 'axios';
const AddWalletModal = ({ isOpen, onClose, customers, onSaveWallet }) => {
  const [ownerId, setOwnerId] = useState('');
  const [currency, setCurrency] = useState('USDC');
  const API_BASE = "http://localhost:3001";
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!ownerId) {
      alert('Please select an owner for the new wallet.');
      return;
    }
    console.log("Selected Owner ID:", ownerId);
    const selectedCustomer = customers.find(cust => cust.cust_id === ownerId);
    if (!selectedCustomer) {
      alert('Selected customer not found.');
      return;
    }
//walletId,owner,walletAddress, stablecoinCurrency,status, createdBy,createdOn,balance,approvers, approvalsRequired
console.log("Selected Customer:",  selectedCustomer.cust_id);
    const newWallet = {
      walletId: `w${Date.now()}`, // Simple ID generation
      owner: ownerId,
      walletAddress: '0x74A270F061161E625DdA715B9AFC27f8A2805C52', // Mock address
      stablecoinCurrency: currency,
      status: 'Active',
      createdBy: 'admin', // Assuming admin creates the wallet
      createdOn: new Date().toISOString().slice(0, 10), // Current date
      balance: '0.00',
      approvers: ["0xB0F5d97bC2830FF933EFa373a0C1685f97F590eF","0x595D43ea09afEB18c6fD72dB84C2b9D4ab245466"],
      approvalsRequired: 1

    };
    try {
      const res = await axios.post(`${API_BASE}/api/wallets/create`, {
        walletId: newWallet.walletId,
        owner: newWallet.owner,
        walletAddress: newWallet.walletAddress,
        stablecoinCurrency: newWallet.stablecoinCurrency,
        status: newWallet.status,
        createdBy: newWallet.createdBy,
        createdOn: newWallet.createdOn,
        balance: newWallet.balance,
        approvers: newWallet.approvers,
        approvalsRequired: newWallet.approvalsRequired  
      });
      console.log("New Wallet Data:", res.data);
      alert("New Customer created: " + res.data.wallet);
      onSaveWallet(newWallet, ownerId);

      }catch(err) {
        alert(err.response?.data?.error || err.message);
    }
   
    onClose();
    setOwnerId('');
    setCurrency('USDC');
  };
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50">
      <div className="bg-white p-8 rounded-lg shadow-xl max-w-md w-full mx-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-2xl font-bold text-gray-800">Add New Wallet</h3>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-300 rounded-md"
          >
            <X size={24} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="walletOwner" className="block text-sm font-medium text-gray-700 mb-1">Wallet Owner</label>
            <select
              id="walletOwner"
              value={ownerId}
              onChange={(e) => setOwnerId(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 bg-white"
              required
            >
              <option value="">Select an owner</option>
              {customers.map((customer) => (
                <option key={customer.cust_id} value={customer.cust_id}>
                  {customer.name} ({customer.email})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="newWalletCurrency" className="block text-sm font-medium text-gray-700 mb-1">Stablecoin Type</label>
            <select
              id="newWalletCurrency"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 bg-white"
            >
              <option value="USDC">USDC</option>
              <option value="USDT">USDT</option>
              <option value="DAI">DAI</option>
              <option value="BUSD">BUSD</option>
            </select>
          </div>
          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50"
          >
            Create Wallet
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddWalletModal;
