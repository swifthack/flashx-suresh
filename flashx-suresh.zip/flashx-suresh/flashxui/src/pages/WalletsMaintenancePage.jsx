import React, { useEffect,useState } from 'react';
import { PlusCircle, Wallet, X } from 'lucide-react';
import AddWalletModal from '../components/AddWalletModal.jsx';
import axios from 'axios';
const API_BASE = "http://localhost:3001";
const WalletsMaintenancePage = ({ customers, onAddCustomerWallet }) => {
  const [isModalOpen, setIsModalOpen] = useState(false); // State to control modal visibility
  const [allWallets, setAllWallets] = useState([]);

  useEffect(() => {
    const fetchWallets = async () => {
      try {
     /**   const res = await axios.get(`${API_BASE}/api/wallets`);
        console.log("Fetched Wallets:", res.data.wallets);
        setAllWallets(res.data.wallets); // assuming the backend returns { wallets: [...] }*/
        axios.get(`${API_BASE}/api/wallets`)
        .then(res => {
          console.log("Response:", res.data);
          const walletList = res.data || []; 
          setAllWallets(walletList);
        })
        .catch(err => console.error(err));
      } catch (err) {
        setAllWallets([]);
        console.error("Error fetching wallets:", err.message);
      }
    };

    fetchWallets();
  }, []);

  const handleSaveWallet = (newWallet, customerId) => {
    setAllWallets([...allWallets, newWallet]);
    onAddCustomerWallet(customerId); // Notify App to update customer's wallet count
  };

  return (
    <div className="p-6">
      <h2 className="text-3xl font-extrabold text-gray-800 mb-6">Wallet Maintenance</h2>

      <div className="flex justify-end mb-4">
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50 flex items-center"
        >
          <PlusCircle size={20} className="mr-2" /> Add Wallet
        </button>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-md border border-gray-200">
        <h3 className="text-xl font-semibold text-gray-700 mb-4">All Stablecoin Wallets</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider rounded-tl-lg">
                  Wallet ID
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Owner
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Address
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Currency
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Balance
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider rounded-tr-lg">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody className="bg-white divide-y divide-gray-200">{
              allWallets.map((wallet) => (
                  <tr key={wallet.wallet_id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{wallet.wallet_id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{wallet.owner}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{wallet.wallet_address}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{wallet.stablecoin_currency}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{wallet.balance}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{wallet.status}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <button
                        onClick={() => handleEditCustomerClick(wallet)}
                        className="text-indigo-600 hover:text-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50"
                      >
                        <Wallet size={16} className="inline-block mr-1" /> Edit
                      </button>
                      <button
                        onClick={() => handleDeleteCustomerClick(wallet.id)}
                        className="text-red-600 hover:text-red-900 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50 ml-2"
                      >
                        <X size={16} className="inline-block mr-1" /> Delete
                      </button>
                    </td>
                  </tr>
              ))
            }
            </tbody>

          
          </table>
        </div>
      </div>

      {/* Add Wallet Modal */}
      <AddWalletModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        customers={customers}
        onSaveWallet={handleSaveWallet}
      />
    </div>
  );
};

export default WalletsMaintenancePage;
