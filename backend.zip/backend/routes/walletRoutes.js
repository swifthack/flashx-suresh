const express = require('express');
const router = express.Router();
const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const FACTORY_ABI = require('../abi/CustodialWalletFactory.json').abi;
const WALLET_ABI = require('../abi/CustodialWallet.json').api;
const TESTUSDC_ABI = require('../abi/TestUSDC.json').abi;

const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
const signer = new ethers.Wallet(process.env.SIGNER_PRIVATE_KEY, provider);
const factory = new ethers.Contract(process.env.FACTORY_ADDRESS, FACTORY_ABI, signer);
const testUSDC = new ethers.Contract(process.env.TESTUSDC_ADDRESS, TESTUSDC_ABI, signer);
 // Replace with your USDC/USDT address
let owners = {};
let wallets = [];

router.post('/owner/create', async (req, res) => {
  const wallet = ethers.Wallet.createRandom();
  owners[wallet.address] = wallet.privateKey;
  res.json({ address: wallet.address, privateKey: wallet.privateKey });
});

/**
 * create a new custodial wallet
 * @param {string} ownerAddress - the address of the owner
 * @returns {string} walletAddress - the address of the new wallet
 */
router.post('/createCustodialWallet', async (req, res) => {
  const { ownerAddress } = req.body;
  if (!ethers.isAddress(ownerAddress)) return res.status(400).json({ error: 'Invalid address' });
  const tx = await factory.createWallet(process.env.TESTUSDC_ADDRESS, ownerAddress);
  const receipt = await tx.wait();
  const event = receipt.logs.map(log => {
    try { return factory.interface.parseLog(log); } catch { return null; }
  }).find(e => e && e.name === 'WalletCreated');
    const walletAddress = event.args.wallet;
    console.log(`New Custodial wallet created: ${walletAddress}`);
    wallets.push(walletAddress);
    res.json({ wallet: walletAddress });
});

router.post('/mint', async (req, res) => {
  try {
    
    const { toAddress, amount } = req.body;
    console.log(`Minting ${amount} USDC to ${toAddress}`);
    const mintAmount = ethers.parseUnits(amount.toString(), 6);
    const tx = await testUSDC.mint(toAddress, mintAmount);
    await tx.wait();
    res.json({ txHash: tx.hash });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create wallet' });
  }
});
/**
 * utility function to create a new owner address
 * need to store this address in database per owner
 */
router.get('/createOwnerAddress', async (req, res) => {
    //write logic to check if owner exists in database
    // if not, create a new owner address
    // for now, we will just create a random address
    const ownerwalletAddress = ethers.Wallet.createRandom();
    console.log("Address:", ownerwalletAddress.address);  
    console.log("Private Key:", ownerwalletAddress.privateKey); // store securely!
    res.json({
        address: ownerwalletAddress.address,
        privateKey: ownerwalletAddress.privateKey
      });
    return ownerwalletAddress.address;
  });

router.post('/approve', async (req, res) => {
    const { ownerPrivateKey,amount } = req.body;
    const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
    
    //const ownerWallet = new ethers.Wallet("0x3d68e6433a8f01ba16ba2eec3f56db4f51cfcf352388b4926b79d4cc6f463562", provider);
    // const token = new ethers.Contract(process.env.TESTUSDC_ADDRESS, TESTUSDC_ABI, signer);    
    // const tx = await token.approve(signer.address, ethers.parseUnits(amount, 6));
    // await tx.wait();
    // console.log("Approved:", tx.hash);
    // res.json({ txHash: tx.hash });


      // 🔑 Load owner signer
      const OWNER_PRIVATE_KEY = ownerPrivateKey;
  const ownerWallet = new ethers.Wallet(OWNER_PRIVATE_KEY, provider);
  const ownerAddress = await ownerWallet.getAddress();
    const VASP_ADDRESS = signer.address; // VASP address is the signer address
  // 🎯 Load TestUSDC contract
  const token = new ethers.Contract(process.env.TESTUSDC_ADDRESS, TESTUSDC_ABI, ownerWallet);

  console.log(`Approving VASP (${VASP_ADDRESS}) to spend USDC from Owner (${ownerAddress})...`);

  // 📤 Send approval
  const tx = await token.approve(VASP_ADDRESS, ethers.parseUnits(amount, 6));
  await tx.wait();

  // 🔎 Check allowance
  const allowance = await token.allowance(ownerAddress, VASP_ADDRESS);
  console.log("✅ Approval complete. Allowance:", ethers.formatUnits(allowance, 6));
  res.json({ txHash: tx.hash });
  });

router.post('/transferFrom', async (req, res) => {
  const { fromAddress, toAddress, amount } = req.body;
  const parsed = ethers.parseUnits(amount.toString(), 6);
  const allowance = await testUSDC.allowance(fromAddress, signer.address);
  const balance = await testUSDC.balanceOf(fromAddress);
  console.log(`Transferring ${amount} USDC from ${fromAddress} to ${toAddress}`);
  console.log(`Allowance: ${ethers.formatUnits(allowance, 6)}, Balance: ${ethers.formatUnits(balance, 6)}`);
  if (allowance < parsed) return res.status(400).json({ error: 'Insufficient allowance' });
  if (balance < parsed) return res.status(400).json({ error: 'Insufficient balance' });
  const tx = await testUSDC.transferFrom(fromAddress, toAddress, parsed);
  await tx.wait();
  res.json({ txHash: tx.hash });
});

router.get('/:walletAddress/balance', async (req, res) => {
  const balance = await testUSDC.balanceOf(req.params.walletAddress);
  res.json({ balance: ethers.formatUnits(balance, 6) });
});

module.exports = router;
