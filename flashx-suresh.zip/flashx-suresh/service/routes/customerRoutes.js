// routes/customerRoutes.js
const express = require('express');
const router = express.Router(); // Create an Express Router
const pool = require('../database/db'); // Import the PostgreSQL connection pool

// GET all customers
router.get('/', async (req, res) => {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT * FROM customers ORDER BY username');
    client.release();
    res.status(200).json(result.rows);
  } catch (error) {
    console.error('Error fetching customers:', error);
    res.status(500).json({ message: 'Failed to fetch customers.', error: error.message });
  }
});

// GET a single customer by ID
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT * FROM customers WHERE cust_id = $1', [id]);
    console.log("result", result);
    client.release();
    if (result.rows.length > 0) {
      res.status(200).json(result.rows[0]);
    } else {
      res.status(404).json({ message: 'Customer not found.' });
    }
  } catch (error) {
    console.error(`Error fetching customer with ID ${id}:`, error);
    res.status(500).json({ message: 'Failed to fetch customer.', error: error.message });
  }
});

// CREATE a new customer
router.post('/create', async (req, res) => {
  console.log("inside create customer route", req.body);
  const { id, name, email, organization, glei, status, wallets, lastLogin } = req.body;
  
  try {
    const client = await pool.connect();
    const result = await client.query(
      'INSERT INTO customers (cust_id, username, email, organization, glei, status, wallets, last_login) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
      [id, name, email, organization, glei, status, wallets, lastLogin]
    );
    client.release();
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating customer:', error);
    res.status(500).json({ message: 'Failed to create customer.', error: error.message });
  }
});

// UPDATE an existing customer
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { name, email, organization, glei, status, wallets, lastLogin } = req.body;
  try {
    const client = await pool.connect();
    const result = await client.query(
      'UPDATE Customers SET name = $1, email = $2, organization = $3, glei = $4, status = $5, wallets = $6, last_login = $7 WHERE id = $8 RETURNING *',
      [name, email, organization, glei, status, wallets, lastLogin, id]
    );
    client.release();
    if (result.rows.length > 0) {
      res.status(200).json(result.rows[0]);
    } else {
      res.status(404).json({ message: 'Customer not found.' });
    }
  } catch (error) {
    console.error(`Error updating customer with ID ${id}:`, error);
    res.status(500).json({ message: 'Failed to update customer.', error: error.message });
  }
});

// DELETE a customer
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const client = await pool.connect();
    const result = await client.query('DELETE FROM customers WHERE id = $1 RETURNING id', [id]);
    client.release();
    if (result.rows.length > 0) {
      res.status(200).json({ message: `Customer with ID ${id} deleted successfully.` });
    } else {
      res.status(404).json({ message: 'Customer not found.' });
    }
  } catch (error) {
    console.error(`Error deleting customer with ID ${id}:`, error);
    res.status(500).json({ message: 'Failed to delete customer.', error: error.message });
  }
});

module.exports = router; // Export the router
