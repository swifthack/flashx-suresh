const {Web3} = require('web3')
const fs = require("fs")
const { abi } = JSON.parse(fs.readFileSync("artifacts/CandidatePassport.json"))

async function main(){
	//Configuring the connection to an Ethereum node
	const network = process.env.ETHEREUM_NETWORK
	const web3 = new Web3(
		new Web3.providers.HttpProvider(
		  'https://sepolia.infura.io/v3/24efa80cb991439d81106df13f2d5d71'
		)
	  )

    // Creating a signing account from a private key
  	const signer = web3.eth.accounts.privateKeyToAccount("0x"+process.env.SIGNER_PRIVATE_KEY);
  	console.log("Signer ",signer)
 	web3.eth.accounts.wallet.add(signer);

	// create a contract instance
	const contract = new web3.eth.Contract(abi, process.env.CAREERPASSPORT_CONTRACT);

	// issue a transaction that calls echo function of contract
	
	const registerCandidate = contract.methods.addCandidate("swift","swifthack@abc.com","individual","Photo1").encodeABI();
	const tx = {
		from: signer.address,
		to: contract.options.address,
		data: registerCandidate,
		value:"0",
		gasPrice:"157981809092",
	}
	
	sendTransactionToNetwork(web3,signer,network,tx)
	
}

async function sendTransactionToNetwork(web3,_signer,_network,_transaction){
	//estimate gas required 
	const gas_estimate = await web3.eth.estimateGas(_transaction)
	console.log("gas_estimate ",gas_estimate);
	_transaction.gas = gas_estimate
	
	const signedTx = await web3.eth.accounts.signTransaction(
		_transaction,
		_signer.privateKey
	)
	console.log("Raw transaction data ", signedTx.rawTransaction)

	// send the transaciton to the network
	const receipt = await web3.eth
		.sendSignedTransaction(signedTx.rawTransaction)
		.once("transactionHash", (txhash) => {
			console.log('Mining transaciton ..... ')
			console.log(`https://${_network}.etherscan.io/tx/${txhash}`)
		})
	// transaction will be created on the chain 
	// get the block number
	console.log(` Mined in block ${receipt.blockNumber}`)
}

require("dotenv").config()
main()