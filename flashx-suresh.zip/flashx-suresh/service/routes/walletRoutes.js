const express = require("express");
const router = express.Router();
const { ethers } = require("ethers");
const pool = require("../database/db");
const fs = require("fs");
const dotenv = require("dotenv");
const abi = JSON.parse(fs.readFileSync("artifacts/contracts/CustodialWallet.sol/CustodialWallet.json")).abi;
const factoryAbi = JSON.parse(fs.readFileSync("artifacts/contracts/CustodialWallet.sol/WalletFactory.json")).abi;
const erc20Abi = JSON.parse(fs.readFileSync("artifacts/contracts/ERC20/ERC20.json")).abi;

const provider = new ethers.JsonRpcProvider("https://sepolia.infura.io/v3/<URL>");
const signer = new ethers.Wallet("<<>>", provider);
const factory = new ethers.Contract("<<>>", factoryAbi, wallet);

/**
 * Represents the customer or beneficiary of the wallet.
Typically a bank's client or end-user.
Does not participate in transaction approvals unless explicitly added as an approver.
The owner can view balances and transactions, but cannot approve or execute unless also an approver.
Think of owner as:
“This wallet is owned by X, but X may not directly control spending unless granted approval rights.”

A wallet authorized to approve token transfers.
Usually internal bank staff, back-office systems, or automated roles.
You define how many approvals are required (approvalsRequired) to execute a transaction.
Multiple approvers can exist (e.g., 2 of 3 multi-sig).
Think of approvers as:
“These are the people or bots who must agree before funds can move from the wallet.”
 */

/**
 * Create a new wallet and store it in the database.
 */
router.post("/create", async (req, res) => {
    console.log("Creating new wallet with data:", req.body);
  const { walletId,owner,walletAddress, stablecoinCurrency,status, createdBy,createdOn,balance,approvers, approvalsRequired} = req.body;
  try {
    //walletAddress refers to an address temporarily used to create the wallet.
    const tx = await factory.createWallet(walletAddress, approvers, approvalsRequired);
    const receipt = await tx.wait();
    console.log("Wallet creation transaction hash:", receipt.transactionHash);
    console.log("receipt.logs", receipt.logs);
    
    const iface = factory.interface;
    const event = receipt.logs
        .map(log => {
            try {
                return iface.parseLog(log);
            } catch {
                return null;
            }
    })
    .find(parsed => parsed && parsed.name === "WalletCreated");
    // check if the event is successfull and thenstore the wallet in the database for the owner which can be viewed by admin as well as the owner
    if (!event) {
        return res.status(500).json({ error: "WalletCreated event not found" });
    }else{
        const wallet = event.args.wallet;
        await pool.query(
        "INSERT INTO wallets (wallet_id,owner,wallet_address, stablecoin_currency,status, created_by,created_on,balance,approvers, approvals_required) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)",
        [walletId,owner,wallet, stablecoinCurrency,status, createdBy,createdOn,balance,approvers, approvalsRequired]
        );
        console.log("Wallet stored in database:", wallet);
        res.json({ wallet });
    }

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET all wallets for administrator
router.get('/', async (req, res) => {
    console.log("Fetching all wallets for admin");

    try {
      const client = await pool.connect();
      const result = await client.query('SELECT * FROM wallets order by created_on desc');
      client.release();
      res.status(200).json(result.rows);
    } catch (error) {
      console.error('Error fetching customers:', error);
      res.status(500).json({ message: 'Failed to fetch customers.', error: error.message });
    }
  });
// GET all wallets for a specific owner 
router.get('/:owner', async (req, res) => {
    const { owner} = req.body;
    try {
      const client = await pool.connect();
      const result = await client.query('SELECT * FROM wallets where owner= $1', [owner]);
      client.release();
      res.status(200).json(result.rows);
    } catch (error) {
      console.error('Error fetching customers:', error);
      res.status(500).json({ message: 'Failed to fetch customers.', error: error.message });
    }
  });
router.post("/:address/submit", async (req, res) => {
  const { token, to, amount } = req.body;
  const walletAddr = req.params.address;
  try {
    const walletContract = new ethers.Contract(walletAddr, abi, signer);
    const tx = await walletContract.submitTokenTransfer(token, to, amount);
    await tx.wait();
    res.json({ txHash: tx.hash });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/:address/approve", async (req, res) => {
  const { txIndex } = req.body;
  const walletAddr = req.params.address;
  try {
    const walletContract = new ethers.Contract(walletAddr, abi, signer);
    const tx = await walletContract.approveTransfer(txIndex);
    await tx.wait();
    res.json({ txHash: tx.hash });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/:address/execute", async (req, res) => {
  const { txIndex } = req.body;
  const walletAddr = req.params.address;
  try {
    const walletContract = new ethers.Contract(walletAddr, abi, signer);
    const tx = await walletContract.executeTransfer(txIndex);
    await tx.wait();
    res.json({ txHash: tx.hash });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/:address/balance/:token", async (req, res) => {
  const { address, token } = req.params;
  try {
    const walletContract = new ethers.Contract(address, abi, provider);
    const balance = await walletContract.getTokenBalance(token);
    res.json({ balance: ethers.formatUnits(balance, 6) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/:address/transfer/:txIndex", async (req, res) => {
  const { address, txIndex } = req.params;
  try {
    const walletContract = new ethers.Contract(address, abi, provider);
    const txInfo = await walletContract.getTransfer(txIndex);
    res.json(txInfo);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/:address/deposit", async (req, res) => {
  const { tokenAddress, amount } = req.body;
  const walletAddress = req.params.address;

  try {
    const token = new ethers.Contract(tokenAddress, erc20Abi, signer);
    const decimals = await token.decimals();
    const tx = await token.transfer(walletAddress, ethers.parseUnits(amount.toString(), decimals));
    await tx.wait();

    // Optional: Log the deposit to the database
    await pool.query(
      "INSERT INTO deposits_withdrawals (cust_id, username, wallet_address, stablecoin_currency,action_performed, amount, tx_hash) VALUES ($1, $2, $3, $4)",
      [walletAddress, tokenAddress, amount, tx.hash]
    );

    res.json({ success: true, txHash: tx.hash });
  } catch (err) {
    console.error("Deposit error:", err);
    res.status(500).json({ error: err.message });
  }
});
module.exports = router;