// db.js
const { Pool } = require('pg');

// --- PostgreSQL Database Configuration ---
// Replace these with your actual PostgreSQL credentials
const pool = new Pool({
    user: 'tbd',        // Your PostgreSQL username
    host: 'localhost',             // Your database host (usually localhost for local setup)
    database: 'tbd',      // The database name you created
    password: 'tbd', // The password for your database user
    port: 5432,                    // The default PostgreSQL port
  });

// Optional: Test connection when the pool is created
pool.on('connect', () => {
  console.log('Connected to PostgreSQL database.');
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
  process.exit(-1); // Exit process if unhandled error occurs
});

// Export the pool to be used in other parts of your application
module.exports = pool;