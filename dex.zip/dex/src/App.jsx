import React, { useState, useEffect } from 'react';

// Main App component
const App = () => {
  // State for wallet connection
  const [walletAddress, setWalletAddress] = useState('');
  const [isWalletConnected, setIsWalletConnected] = useState(false);

  // State for token deposit/buy
  const [tokenType, setTokenType] = useState('USDC');
  const [depositAmount, setDepositAmount] = useState('');
  const [buyAmount, setBuyAmount] = useState('');

  // State for token approval/transfer
  const [availableTokens, setAvailableTokens] = useState(0); // Simulated available tokens
  const [approveAmount, setApproveAmount] = useState(''); // Amount for approval
  const [transferAmount, setTransferAmount] = useState(''); // Amount for transfer
  const [isApproved, setIsApproved] = useState(false);
  const [approvedAmount, setApprovedAmount] = useState(0); // Track the amount that has been approved
  const [targetAddress, setTargetAddress] = useState(''); // State for target address, now primarily for transfer
  const [message, setMessage] = useState(''); // General message for user feedback

  // Mock custodial addresses
  const mockCustodialAddresses = [
    '0xCustodial1A2B3C4D5E6F7G8H9I0J1K2L3M4N5O6P7Q8R9S0T',
    '0xCustodial2B3C4D5E6F7G8H9I0J1K2L3M4N5O6P7Q8R9S0T1U',
    '0xCustodial3C4D5E6F7G8H9I0J1K2L3M4N5O6P7Q8R9S0T1U2V',
  ];

  // Simulate wallet creation
  const handleCreateWallet = () => {
    // For this simulation, we generate a mock address
    const mockAddress = `0x${Math.random().toString(16).substring(2, 42)}`;
    setWalletAddress(mockAddress);
    setIsWalletConnected(true);
    setMessage('New wallet created successfully!');
    // Reset available tokens and approval when a new wallet is created
    setAvailableTokens(0);
    setIsApproved(false);
    setApproveAmount('');
    setTransferAmount('');
    setApprovedAmount(0);
    setTargetAddress(''); // Clear target address
  };

  // Simulate token deposit
  const handleDeposit = () => {
    if (!isWalletConnected) {
      setMessage('Please create or connect your wallet first.');
      return;
    }
    if (depositAmount <= 0 || isNaN(parseFloat(depositAmount))) {
      setMessage('Deposit amount must be a positive number.');
      return;
    }
    // Simulate adding tokens to available balance
    setAvailableTokens(prev => prev + parseFloat(depositAmount));
    setMessage(`${parseFloat(depositAmount).toFixed(2)} ${tokenType} deposited. You now have ${(availableTokens + parseFloat(depositAmount)).toFixed(2)} ${tokenType}.`);
    setDepositAmount(''); // Clear input
    setIsApproved(false); // Reset approval if new tokens are deposited
    setApprovedAmount(0); // Reset approved amount
  };

  // Simulate buying tokens (this would typically involve swapping)
  const handleBuy = () => {
    if (!isWalletConnected) {
      setMessage('Please create or connect your wallet first.');
      return;
    }
    if (buyAmount <= 0 || isNaN(parseFloat(buyAmount))) {
      setMessage('Buy amount must be a positive number.');
      return;
    }
    // In a real DEX, this would involve a swap, for now, just a message
    setMessage(`Attempting to buy ${parseFloat(buyAmount).toFixed(2)} ${tokenType}. (Simulation: No actual swap occurred)`);
    setBuyAmount(''); // Clear input
  };

  // Simulate approving tokens
  const handleApprove = () => {
    if (!isWalletConnected) {
      setMessage('Please create or connect your wallet first.');
      return;
    }
    if (approveAmount <= 0 || isNaN(parseFloat(approveAmount))) {
      setMessage('Please enter a valid amount to approve.');
      return;
    }
    if (parseFloat(approveAmount) > availableTokens) {
      setMessage('Insufficient tokens for approval.');
      return;
    }
    // In a real scenario, this would be an ERC-20 approve call to a smart contract
    setIsApproved(true);
    setApprovedAmount(parseFloat(approveAmount));
    setMessage(`${parseFloat(approveAmount).toFixed(2)} ${tokenType} approved for transfer.`);
  };

  // Simulate transferring tokens to custodial wallet
  const handleTransfer = () => {
    if (!isWalletConnected) {
      setMessage('Please create or connect your wallet first.');
      return;
    }
    if (!isApproved || approvedAmount === 0) {
      setMessage('Please approve tokens first before transferring.');
      return;
    }
    if (transferAmount <= 0 || isNaN(parseFloat(transferAmount))) {
      setMessage('Please enter a valid amount to transfer.');
      return;
    }
    if (parseFloat(transferAmount) > availableTokens) {
      setMessage('Insufficient tokens in your wallet for this transfer.');
      return;
    }
    if (parseFloat(transferAmount) > approvedAmount) {
      setMessage(`You can only transfer up to the approved amount of ${approvedAmount.toFixed(2)} ${tokenType}.`);
      return;
    }
    if (!targetAddress) {
      setMessage('Please select a target custodial address.');
      return;
    }

    // Simulate deducting tokens and resetting approval
    setAvailableTokens(prev => prev - parseFloat(transferAmount));
    setMessage(`${parseFloat(transferAmount).toFixed(2)} ${tokenType} transferred to custodial wallet (${targetAddress}). Remaining: ${(availableTokens - parseFloat(transferAmount)).toFixed(2)} ${tokenType}.`);
    setTransferAmount(''); // Clear input
    setIsApproved(false); // Reset approval after transfer
    setApprovedAmount(0); // Reset approved amount
    setTargetAddress(''); // Clear target address after transfer
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 to-blue-900 flex items-center justify-center p-4 font-inter">
      <div className="bg-gray-800 bg-opacity-70 backdrop-blur-lg p-8 rounded-3xl shadow-2xl w-full max-w-2xl border border-gray-700">
        <h1 className="text-4xl font-extrabold text-white text-center mb-4">
          DEXI
        </h1>
        <h2 className="text-xl font-semibold text-gray-300 text-center mb-8">
          DEXI plays Payer role to purchase stablecoins and transfer to Custodial wallet at Payer bank
        </h2>

        {/* Wallet Section */}
        <div className="mb-8 p-6 bg-gray-700 bg-opacity-50 rounded-2xl border border-gray-600">
          <h2 className="text-2xl font-semibold text-white mb-4 flex items-center">
            <svg className="w-6 h-6 mr-2 text-yellow-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1.586l3.293 3.293a1 1 0 010 1.414l-3.293 3.293V17a1 1 0 11-2 0v-1.586l-3.293-3.293a1 1 0 010-1.414L9 4.586V3a1 1 0 011-1zM4 12a2 2 0 100-4 2 2 0 000 4zm12 0a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd"></path>
            </svg>
            Wallet
          </h2>
          {!isWalletConnected ? (
            <button
              onClick={handleCreateWallet}
              className="w-full bg-gradient-to-r from-green-500 to-teal-600 text-white py-3 px-6 rounded-xl text-lg font-bold hover:from-green-600 hover:to-teal-700 transition duration-300 transform hover:scale-105 shadow-lg"
            >
              Create Wallet
            </button>
          ) : (
            <p className="text-gray-300 text-center break-all">
              Connected: <span className="font-mono text-yellow-300">{walletAddress}</span>
            </p>
          )}
          {isWalletConnected && (
            <p className="text-gray-300 text-center mt-2">
              Available {tokenType}: <span className="font-bold text-green-400">{availableTokens.toFixed(2)}</span>
            </p>
          )}
        </div>

        {/* Deposit & Buy Tokens Section */}
        <div className="mb-8 p-6 bg-gray-700 bg-opacity-50 rounded-2xl border border-gray-600">
          <h2 className="text-2xl font-semibold text-white mb-4 flex items-center">
            <svg className="w-6 h-6 mr-2 text-blue-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path d="M8.433 7.412A2.001 2.001 0 0010 6a2 2 0 00-1.567 3.412L10 12l-1.567 2.588A2.001 2.001 0 0010 14a2 2 0 001.567-3.412L10 8l1.567-2.588A2.001 2.001 0 0010 6a2 2 0 00-1.567 3.412z"></path>
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm0 2a10 10 0 100-20 10 10 0 000 20z" clipRule="evenodd"></path>
            </svg>
            Deposit & Buy Tokens
          </h2>
          <div className="mb-4">
            <label htmlFor="tokenType" className="block text-gray-300 text-sm font-bold mb-2">
              Token Type:
            </label>
            <select
              id="tokenType"
              value={tokenType}
              onChange={(e) => setTokenType(e.target.value)}
              className="shadow appearance-none border border-gray-600 rounded-xl w-full py-3 px-4 text-gray-200 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-700"
            >
              <option value="USDC">USDC</option>
              <option value="ETH">ETH</option>
              <option value="DAI">DAI</option>
            </select>
          </div>
          <div className="mb-4">
            <label htmlFor="depositAmount" className="block text-gray-300 text-sm font-bold mb-2">
              Amount to Deposit:
            </label>
            <input
              type="number"
              id="depositAmount"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              placeholder="e.g., 100"
              className="shadow appearance-none border border-gray-600 rounded-xl w-full py-3 px-4 text-gray-200 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-700"
              min="0"
              step="0.01"
            />
          </div>
          <button
            onClick={handleDeposit}
            disabled={!isWalletConnected}
            className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white py-3 px-6 rounded-xl text-lg font-bold hover:from-indigo-600 hover:to-purple-700 transition duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Deposit {tokenType}
          </button>

          <div className="mt-6 mb-4">
            <label htmlFor="buyAmount" className="block text-gray-300 text-sm font-bold mb-2">
              Amount to Buy:
            </label>
            <input
              type="number"
              id="buyAmount"
              value={buyAmount}
              onChange={(e) => setBuyAmount(e.target.value)}
              placeholder="e.g., 50"
              className="shadow appearance-none border border-gray-600 rounded-xl w-full py-3 px-4 text-gray-200 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-700"
              min="0"
              step="0.01"
            />
          </div>
          <button
            onClick={handleBuy}
            disabled={!isWalletConnected}
            className="w-full bg-gradient-to-r from-pink-500 to-red-600 text-white py-3 px-6 rounded-xl text-lg font-bold hover:from-pink-600 hover:to-red-700 transition duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Buy {tokenType}
          </button>
        </div>

        {/* Approve Tokens Section */}
        <div className="mb-8 p-6 bg-gray-700 bg-opacity-50 rounded-2xl border border-gray-600">
          <h2 className="text-2xl font-semibold text-white mb-4 flex items-center">
            <svg className="w-6 h-6 mr-2 text-orange-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clipRule="evenodd"></path>
            </svg>
            Approve Tokens
          </h2>
          <div className="mb-4">
            <label htmlFor="approveAmount" className="block text-gray-300 text-sm font-bold mb-2">
              Amount to Approve:
            </label>
            <input
              type="number"
              id="approveAmount"
              value={approveAmount}
              onChange={(e) => {
                setApproveAmount(e.target.value);
                setIsApproved(false); // Reset approval if amount changes
                setApprovedAmount(0);
              }}
              placeholder="e.g., 25"
              className="shadow appearance-none border border-gray-600 rounded-xl w-full py-3 px-4 text-gray-200 leading-tight focus:outline-none focus:ring-2 focus:ring-orange-500 bg-gray-700"
              min="0"
              step="0.01"
            />
          </div>
          <button
            onClick={handleApprove}
            disabled={!isWalletConnected || approveAmount <= 0 || parseFloat(approveAmount) > availableTokens || isApproved}
            className="w-full bg-gradient-to-r from-yellow-500 to-orange-600 text-white py-3 px-6 rounded-xl text-lg font-bold hover:from-yellow-600 hover:to-orange-700 transition duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isApproved ? `Approved ${approvedAmount.toFixed(2)} ${tokenType}!` : 'Approve Tokens'}
          </button>
          {isApproved && (
            <p className="text-gray-400 text-center mt-2 text-sm">
              <span className="font-bold text-green-300">{approvedAmount.toFixed(2)} {tokenType}</span> approved for transfer.
            </p>
          )}
        </div>

        {/* Transfer Tokens Section */}
        <div className="mb-8 p-6 bg-gray-700 bg-opacity-50 rounded-2xl border border-gray-600">
          <h2 className="text-2xl font-semibold text-white mb-4 flex items-center">
            <svg className="w-6 h-6 mr-2 text-teal-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clipRule="evenodd"></path>
            </svg>
            Transfer Tokens
          </h2>
          <div className="mb-4">
            <label htmlFor="targetAddressTransfer" className="block text-gray-300 text-sm font-bold mb-2">
              Target Custodial Address:
            </label>
            <select
              id="targetAddressTransfer"
              value={targetAddress}
              onChange={(e) => {
                setTargetAddress(e.target.value);
                // No need to reset approval here, as approval is for the amount, not the address
              }}
              className="shadow appearance-none border border-gray-600 rounded-xl w-full py-3 px-4 text-gray-200 leading-tight focus:outline-none focus:ring-2 focus:ring-teal-500 bg-gray-700"
            >
              <option value="">Select an address</option>
              {mockCustodialAddresses.map((address, index) => (
                <option key={index} value={address}>
                  {address}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-4">
            <label htmlFor="transferAmount" className="block text-gray-300 text-sm font-bold mb-2">
              Amount to Transfer:
            </label>
            <input
              type="number"
              id="transferAmount"
              value={transferAmount}
              onChange={(e) => setTransferAmount(e.target.value)}
              placeholder={`Max ${approvedAmount.toFixed(2)}`}
              className="shadow appearance-none border border-gray-600 rounded-xl w-full py-3 px-4 text-gray-200 leading-tight focus:outline-none focus:ring-2 focus:ring-teal-500 bg-gray-700"
              min="0"
              step="0.01"
            />
          </div>
          <p className="text-gray-400 text-sm mb-4">
            Approved for transfer: <span className="font-bold text-green-300">{approvedAmount.toFixed(2)} {tokenType}</span>
          </p>
          <button
            onClick={handleTransfer}
            disabled={!isWalletConnected || !isApproved || transferAmount <= 0 || parseFloat(transferAmount) > approvedAmount || !targetAddress}
            className="w-full bg-gradient-to-r from-teal-500 to-blue-600 text-white py-3 px-6 rounded-xl text-lg font-bold hover:from-teal-600 hover:to-blue-700 transition duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Transfer Tokens
          </button>
        </div>

        {/* Message Display */}
        {message && (
          <div className="mt-8 p-4 bg-blue-900 bg-opacity-50 rounded-xl border border-blue-800 text-white text-center">
            <p className="text-lg font-medium">{message}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;
