// deploy.js using Hardhat

const { ethers } = require("hardhat");

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with address:", deployer.address);

  // Deploy CustodialWallet (logic reference, not used directly)
  const Wallet = await ethers.getContractFactory("CustodialWallet");
  const walletLogic = await Wallet.deploy();
  await walletLogic.waitForDeployment();
  console.log("CustodialWallet logic deployed at:", walletLogic.target);

  // Deploy WalletFactory with deployer's address as the custodian
  const Factory = await ethers.getContractFactory("WalletFactory");
  const factory = await Factory.deploy(deployer.address);
  await factory.waitForDeployment();
  console.log("WalletFactory deployed at:", factory.target);

  // Save addresses to local file or .env
  console.log("✅ Deployment complete.");
  console.log("WALLET_LOGIC:", walletLogic.target);
  console.log("FACTORY_ADDRESS:", factory.target);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
