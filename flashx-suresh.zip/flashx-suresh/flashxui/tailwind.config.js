/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html", // Vite's index.html is at the root
    "./src/**/*.{js,jsx,ts,tsx}", // Ensure it covers both .js and .jsx
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
