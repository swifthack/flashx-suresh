import React from 'react';
import { User, Wallet, DollarSign, Clock, Users, Shield } from 'lucide-react';

const BankAdminDashboardPage = () => {
  // Mock statistics data for the admin dashboard
  const stats = [
    { title: 'Total Customers', value: '5,230', icon: <Users size={24} className="text-blue-500" /> },
    { title: 'Active Wallets', value: '12,500', icon: <Wallet size={24} className="text-green-500" /> },
    { title: 'Total Volume (USD)', value: '$25M', icon: <DollarSign size={24} className="text-indigo-500" /> },
    { title: 'Pending KYC', value: '45', icon: <Clock size={24} className="text-yellow-500" /> },
  ];

  return (
    <div className="p-6">
      <h2 className="text-3xl font-extrabold text-gray-800 mb-6">Bank Admin Dashboard</h2>

      {/* Statistics Section */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-md border border-gray-200 flex items-center space-x-4">
            <div className="p-3 bg-gray-100 rounded-full">
              {stat.icon}
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">{stat.title}</p>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </section>

      <div className="bg-white p-6 rounded-xl shadow-md border border-gray-200">
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Admin Overview</h3>
        <p className="text-gray-600">
          Welcome, Bank Admin. From here, you can manage various aspects of the platform, including user accounts,
          wallet statuses, and system configurations. Use the navigation on the left to access specific tools.
        </p>
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg flex items-center">
            <User size={20} className="text-blue-600 mr-3" />
            <span className="font-medium text-blue-800">Manage Users</span>
          </div>
          <div className="bg-green-50 p-4 rounded-lg flex items-center">
            <Shield size={20} className="text-green-600 mr-3" />
            <span className="font-medium text-green-800">System Logs</span>
          </div>
          {/* More admin widgets can be added here */}
        </div>
      </div>
    </div>
  );
};

export default BankAdminDashboardPage;
