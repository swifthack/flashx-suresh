// server.js (or app.js)
const express = require('express');
const pool = require('./database/db'); // Import the PostgreSQL connection pool
const customerRoutes = require('./routes/customerRoutes'); // Import customer routes
const walletRoutes = require('./routes/walletRoutes'); // Import wallet routes
const http = require('http'); // Required for making internal HTTP requests

const app = express();
const port = 3001; // Choose a port for your Express server
const dotenv = require("dotenv");
const cors = require("cors");

dotenv.config();

app.use(cors());
app.use(express.json());
// --- Middleware ---
// Enable JSON body parsing for incoming requests
app.use(express.json());

// --- Routes ---
// Basic route to check if the server is running
app.get('/', (req, res) => {
  res.send('Express server is running and ready to connect to PostgreSQL!');
});

// Mount customer routes under /api/customers
app.use('/api/customers', customerRoutes);
// Mount wallet routes under /api/wallets
app.use('/api/wallets', walletRoutes);

// --- Database Connection Test Endpoint (can remain here or be moved to a separate utility) ---
app.get('/test-db-connection', async (req, res) => {
  try {
    const client = await pool.connect();
    await pool.query('SET search_path TO public');
    console.log("Client ",client);
    const result = await client.query('SELECT * from customers');
    client.release();

    res.status(200).json({
      message: 'Successfully connected to PostgreSQL database!',
      databaseTime: result.rows[0],
    });
  } catch (error) {
    console.error('Database connection error:', error);
    res.status(500).json({
      message: 'Failed to connect to PostgreSQL database.',
      error: error.message,
    });
  }
});

// --- Start the Express Server ---
app.listen(port, () => {
  console.log(`Express server listening at http://localhost:${port}`);
  console.log('Attempting to connect to PostgreSQL...');

  // --- Invoke test-db-connection during startup ---
  const options = {
    hostname: 'localhost',
    port: port,
    path: '/test-db-connection',
    method: 'GET',
  };

  const req = http.request(options, (res) => {
    let data = '';
    res.on('data', (chunk) => {
      data += chunk;
    });
    res.on('end', () => {
      if (res.statusCode === 200) {
        console.log('Startup DB Test: Success!', JSON.parse(data));
      } else {
        console.error(`Startup DB Test: Failed with status ${res.statusCode}:`, data);
      }
    });
  });

  req.on('error', (e) => {
    console.error(`Startup DB Test: Request error: ${e.message}`);
  });

  req.end();
  // --- End of startup invocation ---
});

// Optional: Handle graceful shutdown
process.on('SIGINT', () => {
  pool.end(() => {
    console.log('PostgreSQL connection pool closed.');
    process.exit(0);
  });
});
