// Express.js backend for CustodialWallet

const express = require("express");
const { ethers } = require("ethers");
const fs = require("fs");
const dotenv = require("dotenv");
const cors = require("cors");

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const abi = JSON.parse(fs.readFileSync("artifacts/contracts/CustodialWallet.sol/CustodialWallet.json")).abi;
const factoryAbi = JSON.parse(fs.readFileSync("artifacts/contracts/CustodialWallet.sol/WalletFactory.json")).abi;

const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
const wallet = new ethers.Wallet(process.env.SIGNER_PRIVATE_KEY, provider);
console.log(" before factory");
const factory = new ethers.Contract(process.env.FACTORY_ADDRESS, factoryAbi, wallet);

app.post("/wallets/create", async (req, res) => {
    console.log("inside create wallet");
  const { owner, approvers, approvalsRequired } = req.body;
  try {
    const tx = await factory.createWallet(owner, approvers, approvalsRequired);
    const receipt = await tx.wait();
    console.log("Wallet creation transaction hash:", receipt.transactionHash);
    console.log("receipt.logs", receipt.logs);
    //const event = receipt.logs;
    //res.json({ wallet: event.args.wallet });
  } catch (e) {
    console.error("Error creating wallet:", e);
    res.status(500).json({ error: e.message });
  }
});

app.post("/wallets/:address/submit", async (req, res) => {
  const { token, to, amount } = req.body;
  const walletAddr = req.params.address;
  try {
    const cw = new ethers.Contract(walletAddr, abi, wallet);
    const tx = await cw.submitTokenTransfer(token, to, amount);
    await tx.wait();
    res.json({ success: true, txHash: tx.hash });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/wallets/:address/approve", async (req, res) => {
  const { txIndex } = req.body;
  const walletAddr = req.params.address;
  try {
    const cw = new ethers.Contract(walletAddr, abi, wallet);
    const tx = await cw.approveTransfer(txIndex);
    await tx.wait();
    res.json({ success: true, txHash: tx.hash });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/wallets/:address/execute", async (req, res) => {
  const { txIndex } = req.body;
  const walletAddr = req.params.address;
  try {
    const cw = new ethers.Contract(walletAddr, abi, wallet);
    const tx = await cw.executeTransfer(txIndex);
    await tx.wait();
    res.json({ success: true, txHash: tx.hash });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/wallets/:address/balance/:token", async (req, res) => {
  const { address, token } = req.params;
  try {
    const cw = new ethers.Contract(address, abi, provider);
    const bal = await cw.getTokenBalance(token);
    res.json({ balance: ethers.formatUnits(bal, 6) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/wallets/:address/transfer/:txIndex", async (req, res) => {
  const { address, txIndex } = req.params;
  try {
    const cw = new ethers.Contract(address, abi, provider);
    const txInfo = await cw.getTransfer(txIndex);
    res.json(txInfo);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Custodial wallet backend running on port ${PORT}`));